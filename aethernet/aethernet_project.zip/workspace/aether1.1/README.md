# aether1.1

### Future thoughts:

- Modular Settings
Instead of a single settings.py, break it into:
base.py (core settings)

dev.py (development-specific settings)
prod.py (production settings)


### Create and .env file

SECRET_KEY=your-super-secret-key
DEBUG=True


## Key Coding Principles:

### DRY (Don't Repeat Yourself)!
### KISS (Keep It Simple, Stupid!)
### YAGNI (You Ain’t Gonna Need It)

### SOLID Principles (For Object-Oriented Programming)

These are five principles for better OOP design:

Single Responsibility Principle - A class should only have one reason to change.

Open/Closed Principle - Code should be open for extension, but closed for modification.

Liskov Substitution Principle - Subtypes should be usable without altering the behavior.

Interface Segregation Principle - Don't force classes to implement unused methods.

Dependency Inversion Principle - Depend on abstractions rather than concrete implementations.