let temperatureChart, humidityChart, tankLevelChart;

function createCharts() {
    const ctxTemp = document.getElementById("temperatureChart").getContext("2d");
    const ctxHumidity = document.getElementById("humidityChart").getContext("2d");
    const ctxTank = document.getElementById("tankLevelChart").getContext("2d");

    temperatureChart = new Chart(ctxTemp, {
        type: "line",
        data: { labels: [], datasets: [{ label: "Temperature (°C)", data: [], borderColor: "#00ffee", fill: false }] },
        options: { 
            responsive: true,
            maintainAspectRatio: false // Allows chart to stretch to fill container
        }
    });

    humidityChart = new Chart(ctxHumidity, {
        type: "line",
        data: { labels: [], datasets: [{ label: "Humidity (%)", data: [], borderColor: "#A100FF", fill: false }] },
        options: { 
            responsive: true,
            maintainAspectRatio: false
        }
    });

    tankLevelChart = new Chart(ctxTank, {
        type: "line",
        data: { labels: [], datasets: [{ label: "Tank Level (%)", data: [], borderColor: "#39FF14", fill: false }] },
        options: { 
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

    // Function to fetch and update data
    function fetchSensorData() {
        fetch(`${BASE_URL}/sensors/api/sensor-data/`)
            .then(response => response.json())
            .then(data => {
                let currentTime = new Date().toLocaleTimeString();
    
                // ✅ Ensure elements exist before updating them
                const temperatureEl = document.getElementById("temperature");
                if (temperatureEl) temperatureEl.innerText = `${data.sensor_data.temperature} °C`;
    
                const humidityEl = document.getElementById("humidity");
                if (humidityEl) humidityEl.innerText = `${data.sensor_data.humidity} %`;
    
                const rainfallEl = document.getElementById("rainfall");
                if (rainfallEl) rainfallEl.innerText = data.sensor_data.rainfall ? "Yes" : "No";
    
                const tankLevelEl = document.getElementById("tankLevel");
                if (tankLevelEl) tankLevelEl.innerText = `${data.sensor_data.tank_level} %`;
    
                const hvacLoadEl = document.getElementById("hvacLoad");
                if (hvacLoadEl) hvacLoadEl.innerText = `${data.sensor_data.hvac_load} %`;
    
                const decisionEl = document.getElementById("decision");
                if (decisionEl) decisionEl.innerText = data.decision;
    
                // ✅ Update Graphs
                temperatureChart.data.labels.push(currentTime);
                temperatureChart.data.datasets[0].data.push(data.sensor_data.temperature);
                temperatureChart.update();
    
                humidityChart.data.labels.push(currentTime);
                humidityChart.data.datasets[0].data.push(data.sensor_data.humidity);
                humidityChart.update();
    
                tankLevelChart.data.labels.push(currentTime);
                tankLevelChart.data.datasets[0].data.push(data.sensor_data.tank_level);
                tankLevelChart.update();
            })
            .catch(error => console.error("Error fetching data:", error));
    }
    
    
    function overrideDecision(action) {
        fetch(`${BASE_URL}/api/override?decision=${action}`, { method: "GET" })
            .then(response => response.json())
            .then(data => {
                // ✅ Show Visual Confirmation
                const overrideMessage = document.getElementById("overrideMessage");
                overrideMessage.innerText = `Override Applied: ${data.new_decision}`;
                overrideMessage.style.opacity = "1"; // Make it visible
                overrideMessage.style.transform = "scale(1)"; // Animate visibility

                // ✅ Update Decision Box
                document.getElementById("decision").innerText = data.new_decision;

                // ✅ Hide Message After 5 Seconds
                setTimeout(() => {
                    overrideMessage.style.opacity = "0"; 
                    overrideMessage.style.transform = "scale(0.9)";
                }, 5000);
            })
            .catch(error => console.error("Error overriding decision:", error));
    }

    const thresholdForm = document.getElementById("thresholdForm");

    if (thresholdForm) {
        thresholdForm.addEventListener("submit", function (event) {
            event.preventDefault();  // ✅ Stops default form submission

            const humidityThreshold = document.getElementById("humidityThreshold").value;
            const temperatureThreshold = document.getElementById("temperatureThreshold").value;

            fetch(`${BASE_URL}/api/set-thresholds`, {  // ✅ Sends user-defined thresholds to Flask API
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ humidity: humidityThreshold, temperature: temperatureThreshold })
            })
            .then(response => response.json())
            .then(data => {
                const saveMessage = document.getElementById("saveMessage");

                if (saveMessage) {  // ✅ Ensures feedback message exists
                    saveMessage.style.opacity = "1";  // ✅ Shows confirmation
                    setTimeout(() => saveMessage.style.opacity = "0", 3000);  // ✅ Hides after 3 seconds
                }
            })
            .catch(error => console.error("Error saving thresholds:", error));
        });
    }
        
    // Initialize Charts and Set Refresh Interval
    document.addEventListener("DOMContentLoaded", function () {
        const loginForm = document.getElementById("loginForm");
        if (loginForm) {  // ✅ Ensures the element exists before adding the event listener
            loginForm.addEventListener("submit", async function(event) {
                event.preventDefault();
    
                const username = document.getElementById("username").value;
                const password = document.getElementById("password").value;
    
                const response = await fetch(`${BASE_URL}/api/login`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ username, password })
                });
    
                const data = await response.json();
    
                if (response.ok) {
                    localStorage.setItem("user", JSON.stringify(data.user));
                    window.location.href = "/";
                } else {
                    document.getElementById("error-message").textContent = data.error;
                }
            });
        }
    });
    
    